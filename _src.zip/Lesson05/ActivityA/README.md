# ActivityA
Lesson 5 Activity A

## Install Requirements
```
$ make install
```

## Run Tests

```
$ make test
```
