#!/bin/bash
# Install Java
sudo yum install java-1.8.0-openjdk -y
java -version
