def add_numbers(number1, number2):
    return number1 + number2

def add_three_numbers(number1, number2, number3):
    return number1 + number2 + number3
