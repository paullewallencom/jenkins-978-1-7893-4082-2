def sumOfNumbers(a, b):
    """
    a simple function that returns the sum of two values
    """
    sum = a + b
    return sum