

class Message():

    def printMessage(self):
        """
        a simple function that prints a message
        """
        print "Hello World!"


if __name__ == "__main__":
    msg = Message()
    msg.printMessage()
