# Jenkins Views and Setting up Freestyle Projects

In order to run the scripts in this path, follow the instructions below:
1. Ensure you have at least Python 2.7.8 + installed
2. The scripts require no virtual environment to run
3. Run the scripts on your terminal as: python scriptname.py. E.g. python sample.py
